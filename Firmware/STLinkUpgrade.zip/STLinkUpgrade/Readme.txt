1. Flash new ST-Link with Unprotected-2-1-Bootloader.bin 
2. Connect new ST-Link instead of what you just have used
3. Launch ST-LinkUpgrade.exe and select STM32+VCP+MSD. Let it finish.
4. Now it is operational, but you may want to upgrade it to latest version.
5. Use latest ST-Link upgrade tool to upgrade it to whatever you want. Use latest
USB driver from ST to make STDebug operational.